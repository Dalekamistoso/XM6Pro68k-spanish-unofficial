
Overview:

This is a fork of XM6 version 2.06 with a plethora of new features,
the majority of which are user interface or development related.
It also aims to have the most accurate floppy drive emulation.
Please read the change log and reference manual for more details.



Requirements:

 32-bit x86 CPU with MMX (Athlon, Celeron, Duron, Pentium II, etc.)
 Windows 2000 or later
 Visual C++ 2008 Redistributable Package (available on my website)
 DirectX 5 (probably comes installed with any compatible OS)
 CGROM.DAT (optional, available on my website)
 ZLIB1.DLL (optional, available on my website)



Installation:

Extract the files from this archive into a suitable directory.
Next try running the main executable (XM6.exe). If it gives you
an error message, you probably need the VC redistributable package.
See my website for two options, one of which is the DLL package.

It is highly recommended that you also download the aforementioned
DLL package from my website and read the included instructions in
order to enable additional features. The files should be placed
in the same location as the executable.

Similarly, there is also an optional "Web Package" which enables
a few helpful features that utilize the Internet (but only when
explicitly requested to do so by the user). Extract the package
into the same directory as the main executable.

The program itself has the ability to perform minor installation tasks
through the Tools menu. The Install submenu has a list of locations
where a shortcut to XM6 can be installed, and the Uninstall submenu
will revert any or all of the installed shortcuts to XM6. Please note
that certain shortcuts may not show up in your environment.

The desktop shortcut includes a hotkey: Ctrl-Alt-X. As long as the
shortcut is on your desktop, you can press that key combination to
launch XM6.

The "send-to menu" shortcut is quite handy: simply select one or more
disk images, or a state file, in Explorer. Next open the context menu,
select "Send To", and then type 'X' or click the XM6 Pro-68k shortcut.

Uninstallation simply involves deleting the program. Before doing that,
first run the program and select Tools > Uninstall > All Shortcuts from
the menu to delete any shortcuts. (This step is unnecessary if you never
used the menu to explicitly install shortcuts in the first place.)



The Non-Unicode Edition:

There is a second version of the executable in the MBCS subdirectory.
This is the non-Unicode version of the program, which is also known as
the "ANSI" or MBCS edition. It is not recommended for most users,
lacking the updated graphics and flexibility of the Unicode edition.
It is, however, a bit less CPU intensive when running certain games.
It requires all the same files as the main version in order to run.



Troubleshooting:

- You get a message saying the application configuration is incorrect.

The Visual C++ 2008 Redistributable Package needs to be installed.
You can get a recent version of it on my website, along with an
alternative package of DLLs that can be used without being installed.

- You see garbage where you are expecting glyphs.

CGROM.DAT is missing or corrupt. This file isn't technically required,
depending on the software you're trying to run, but is highly recommended.
You can get a copy on my website.

- On startup, you get a warning message about the CG-ROM.

See previous answer.



Website:

The following website is the only official place to get this program:

https://mijet.eludevisibility.org/

https://mijet.eludevisibility.org/XM6 Pro-68k/XM6 Pro-68k.html

For security and configuration management reasons, I'd prefer people
use one of the above links instead of redistributing this program,
but realistically not everyone is going to cooperate, so I advise
the reader to take a few extra minutes and go get the latest version
from the official site.

For extra security, type "XM6 Pro-68k" into an Internet search engine
and make sure the top result matches the Web address in this document.



Acknowledgments:

The author would like to thank Artemio Urbina for his invaluable
contributions to improving emulation accuracy through research.
